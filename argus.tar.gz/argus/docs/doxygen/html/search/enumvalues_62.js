var searchData=
[
  ['bayer_5fchannel_5fb',['BAYER_CHANNEL_B',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daade7e0847d7c46e6ef48a73a5bfa7c0d2',1,'Argus']]],
  ['bayer_5fchannel_5fcount',['BAYER_CHANNEL_COUNT',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa4fe9995810ef6c8d0b0e6293a644ca92',1,'Argus']]],
  ['bayer_5fchannel_5fg_5feven',['BAYER_CHANNEL_G_EVEN',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa3a29cb5745107741b04433b0b640dd2c',1,'Argus']]],
  ['bayer_5fchannel_5fg_5fodd',['BAYER_CHANNEL_G_ODD',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daaa52d2aed864437720e59729ff3f307d4',1,'Argus']]],
  ['bayer_5fchannel_5fr',['BAYER_CHANNEL_R',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa1a67e83aa27df93bdc85cda957c743bd',1,'Argus']]]
];
