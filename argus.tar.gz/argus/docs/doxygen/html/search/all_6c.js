var searchData=
[
  ['left',['left',['../structArgus_1_1Rectangle.html#afde3d52365ef0113d1896039d0cfe56c',1,'Argus::Rectangle::left()'],['../structArgus_1_1NormalizedRect.html#ad7880ac4673b3f1b9c2e3c650d2de54f',1,'Argus::NormalizedRect::left()']]],
  ['location',['Location',['../structArgus_1_1Location.html#a2aff108a305df24647b799f074a62641',1,'Argus::Location::Location()'],['../structArgus_1_1Location.html#af19e3292ac38e3ca1df80dba2c2073f9',1,'Argus::Location::Location(uint32_t a, uint32_t b)']]],
  ['location',['Location',['../structArgus_1_1Location.html',1,'Argus']]]
];
