var searchData=
[
  ['bottom',['bottom',['../structArgus_1_1NormalizedRect.html#a0e6dfdd36297fab3353d73f043c7db92',1,'Argus::NormalizedRect']]]
];
