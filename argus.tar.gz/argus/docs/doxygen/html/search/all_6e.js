var searchData=
[
  ['nameduuid',['NamedUUID',['../classArgus_1_1NamedUUID.html',1,'Argus']]],
  ['nameduuid',['NamedUUID',['../classArgus_1_1NamedUUID.html#a3279cd9db732ce6a3c22220dc3c82bfb',1,'Argus::NamedUUID::NamedUUID(uint32_t time_low_, uint16_t time_mid_, uint16_t time_hi_and_version_, uint16_t clock_seq_, uint8_t c0, uint8_t c1, uint8_t c2, uint8_t c3, uint8_t c4, uint8_t c5, const char *name)'],['../classArgus_1_1NamedUUID.html#a8a123a06ef2136fbb946b56935130d66',1,'Argus::NamedUUID::NamedUUID(const NamedUUID &amp;copied)'],['../classArgus_1_1NamedUUID.html#af3b11599e47273125d7b1f5c795b33e5',1,'Argus::NamedUUID::NamedUUID()']]],
  ['node',['node',['../structArgus_1_1UUID.html#a9634c1f28ccb599d63bd7c92257103ed',1,'Argus::UUID']]],
  ['noncopyable',['NonCopyable',['../classArgus_1_1NonCopyable.html',1,'Argus']]],
  ['noncopyable',['NonCopyable',['../classArgus_1_1NonCopyable.html#a1aad733b06de586e1cee4c0aa8e8ff49',1,'Argus::NonCopyable::NonCopyable()'],['../classArgus_1_1NonCopyable.html#a52f76b8f0c765a71a51a492a9fa59d61',1,'Argus::NonCopyable::NonCopyable(NonCopyable &amp;other)']]],
  ['normalizedrect',['NormalizedRect',['../structArgus_1_1NormalizedRect.html#a1d76cd58bd049b031f0458405391e293',1,'Argus::NormalizedRect::NormalizedRect()'],['../structArgus_1_1NormalizedRect.html#a05eccd6cdd1a00bcbe2cfb09773438b0',1,'Argus::NormalizedRect::NormalizedRect(float l, float t, float r, float b)']]],
  ['normalizedrect',['NormalizedRect',['../structArgus_1_1NormalizedRect.html',1,'Argus']]],
  ['num_5fawb_5fwb_5festimate_5felements',['NUM_AWB_WB_ESTIMATE_ELEMENTS',['../classArgus_1_1ICaptureMetadata.html#a0ec63067082ae5325083f8f3fe217ba9',1,'Argus::ICaptureMetadata']]],
  ['num_5fcolor_5fcorrection_5felements',['NUM_COLOR_CORRECTION_ELEMENTS',['../classArgus_1_1ICaptureMetadata.html#a66ada0c57da176187dd0bb3ac7e1920f',1,'Argus::ICaptureMetadata']]]
];
