var searchData=
[
  ['rgb_5fchannel_5fblue',['RGB_CHANNEL_BLUE',['../namespaceArgus.html#ad708eaf4e83e4551b95cc2f9a8253674a89615778b6b850108bce8d88017ae380',1,'Argus']]],
  ['rgb_5fchannel_5fcount',['RGB_CHANNEL_COUNT',['../namespaceArgus.html#ad708eaf4e83e4551b95cc2f9a8253674a410dbd53edc1206c3c9ea3a46b1c856f',1,'Argus']]],
  ['rgb_5fchannel_5fgreen',['RGB_CHANNEL_GREEN',['../namespaceArgus.html#ad708eaf4e83e4551b95cc2f9a8253674a0494204719f1b7af703cc7ccf0fe6530',1,'Argus']]],
  ['rgb_5fchannel_5fred',['RGB_CHANNEL_RED',['../namespaceArgus.html#ad708eaf4e83e4551b95cc2f9a8253674ad6d124e4c9ecb24ffeeaf7c1ecfc4b22',1,'Argus']]]
];
