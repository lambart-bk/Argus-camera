var searchData=
[
  ['status_5fcancelled',['STATUS_CANCELLED',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3aa55fa5e99bf61b6ef7e4ae1ca5b8db66',1,'Argus']]],
  ['status_5fcount',['STATUS_COUNT',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3adaec86364eed23dc1c6ea5e218698594',1,'Argus']]],
  ['status_5fdisconnected',['STATUS_DISCONNECTED',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a87c974d5788baff2ae26d4fe673744d3',1,'Argus']]],
  ['status_5finvalid_5fparams',['STATUS_INVALID_PARAMS',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a5a8f53a6db51a77a4a98a6d860b05c6f',1,'Argus']]],
  ['status_5finvalid_5fsettings',['STATUS_INVALID_SETTINGS',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3aff5b73628bd366ea62cbd5c40e492daa',1,'Argus']]],
  ['status_5fok',['STATUS_OK',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3ac634101cfcda82a1bd2bdd36adf521e6',1,'Argus']]],
  ['status_5fout_5fof_5fmemory',['STATUS_OUT_OF_MEMORY',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a1e691b265a31a18f6318793519652bda',1,'Argus']]],
  ['status_5ftimeout',['STATUS_TIMEOUT',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a0e849c83b15d5a4a3451a0d836a77bd5',1,'Argus']]],
  ['status_5funavailable',['STATUS_UNAVAILABLE',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a5458780eca91f8bf5cc550278a5024e6',1,'Argus']]],
  ['status_5funimplemented',['STATUS_UNIMPLEMENTED',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3a8e0e3b991e47acd63f5fb30bcd72eb1c',1,'Argus']]]
];
