var searchData=
[
  ['b',['b',['../structArgus_1_1BayerTuple.html#a7a405c9d6103ea4b2908dd90024f171c',1,'Argus::BayerTuple::b()'],['../structArgus_1_1BayerTuple.html#a4493be34f517bc456bb2e33bb5a5bc2c',1,'Argus::BayerTuple::b() const ']]],
  ['bayer_5fchannel_5fb',['BAYER_CHANNEL_B',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daade7e0847d7c46e6ef48a73a5bfa7c0d2',1,'Argus']]],
  ['bayer_5fchannel_5fcount',['BAYER_CHANNEL_COUNT',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa4fe9995810ef6c8d0b0e6293a644ca92',1,'Argus']]],
  ['bayer_5fchannel_5fg_5feven',['BAYER_CHANNEL_G_EVEN',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa3a29cb5745107741b04433b0b640dd2c',1,'Argus']]],
  ['bayer_5fchannel_5fg_5fodd',['BAYER_CHANNEL_G_ODD',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daaa52d2aed864437720e59729ff3f307d4',1,'Argus']]],
  ['bayer_5fchannel_5fr',['BAYER_CHANNEL_R',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6daa1a67e83aa27df93bdc85cda957c743bd',1,'Argus']]],
  ['bayeraveragemap_2eh',['BayerAverageMap.h',['../BayerAverageMap_8h.html',1,'']]],
  ['bayerchannel',['BayerChannel',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6da',1,'Argus']]],
  ['bayersharpnessmap_2eh',['BayerSharpnessMap.h',['../BayerSharpnessMap_8h.html',1,'']]],
  ['bayertuple',['BayerTuple',['../structArgus_1_1BayerTuple.html#a9adf5f2f70d07a6103e0c54c5f850dc3',1,'Argus::BayerTuple::BayerTuple()'],['../structArgus_1_1BayerTuple.html#aff79fd7c4401c44ab5c5e187da189da3',1,'Argus::BayerTuple::BayerTuple(T r, T gEven, T gOdd, T b)']]],
  ['bayertuple',['BayerTuple',['../structArgus_1_1BayerTuple.html',1,'Argus']]],
  ['begin',['begin',['../classArgus_1_1Array2D.html#a29db9087e0f6db131319b36a60b3766c',1,'Argus::Array2D::begin() const '],['../classArgus_1_1Array2D.html#ab5b7e17b7c4be97161807f931da02e39',1,'Argus::Array2D::begin()']]],
  ['bottom',['bottom',['../structArgus_1_1NormalizedRect.html#a0e6dfdd36297fab3353d73f043c7db92',1,'Argus::NormalizedRect']]]
];
