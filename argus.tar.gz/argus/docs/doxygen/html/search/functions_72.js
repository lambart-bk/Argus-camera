var searchData=
[
  ['r',['r',['../structArgus_1_1BayerTuple.html#a29754f59fb3a04b0b23944b36c10cff3',1,'Argus::BayerTuple::r()'],['../structArgus_1_1BayerTuple.html#a566ddd06c9760e3dd14b98f3516d4ae1',1,'Argus::BayerTuple::r() const ']]],
  ['range',['Range',['../structArgus_1_1Range.html#a8bec4b503d2050d516e7c26b4cfc5d0c',1,'Argus::Range::Range(T value)'],['../structArgus_1_1Range.html#a7b7bb69d915ad741f6024e0e60a4ab86',1,'Argus::Range::Range(T min, T max)']]],
  ['rectangle',['Rectangle',['../structArgus_1_1Rectangle.html#a3b23233b39dcf02a6ac64cb6e5795517',1,'Argus::Rectangle::Rectangle()'],['../structArgus_1_1Rectangle.html#af18f8f24ae2fcc65537538f61697d03f',1,'Argus::Rectangle::Rectangle(uint32_t _left, uint32_t _top, uint32_t _width, uint32_t _height)']]],
  ['release',['release',['../classArgus_1_1UniqueObj.html#a6a16389a84396383e7398be6eed5ae07',1,'Argus::UniqueObj']]],
  ['repeat',['repeat',['../classArgus_1_1ICaptureSession.html#a76f0c7a185351ddeb521e4d0f46b8ca2',1,'Argus::ICaptureSession']]],
  ['repeatburst',['repeatBurst',['../classArgus_1_1ICaptureSession.html#aedf68af40770a5728c9a8572dba79da3',1,'Argus::ICaptureSession']]],
  ['reset',['reset',['../classArgus_1_1UniqueObj.html#ae6cb4e063009b5128e9ae1d2ce946c52',1,'Argus::UniqueObj']]],
  ['resize',['resize',['../classArgus_1_1Array2D.html#ac1890f69d116b057dc0af0d634bf2bde',1,'Argus::Array2D']]],
  ['rv',['rv',['../classArgus_1_1rv.html#ac7a9bcfc96bc6f5d57d4f2a3f0b675f7',1,'Argus::rv::rv()'],['../classArgus_1_1rv.html#ad567da8af6cb85c2b5c00e59e183e40b',1,'Argus::rv::rv(const rv &amp;)']]]
];
