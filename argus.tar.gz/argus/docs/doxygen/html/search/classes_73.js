var searchData=
[
  ['sensormode',['SensorMode',['../classArgus_1_1SensorMode.html',1,'Argus']]],
  ['size',['Size',['../structArgus_1_1Size.html',1,'Argus']]]
];
