var searchData=
[
  ['data',['data',['../structArgus_1_1Tuple.html#ab2fce53bff3583fad4ea02a1d6d7d882',1,'Argus::Tuple']]]
];
