var searchData=
[
  ['waitforevents',['waitForEvents',['../classArgus_1_1IEventProvider.html#ab180e35467c20913c1972eead7b071f2',1,'Argus::IEventProvider::waitForEvents(const std::vector&lt; EventQueue * &gt; &amp;queues, uint64_t timeout=TIMEOUT_INFINITE)=0'],['../classArgus_1_1IEventProvider.html#a54740e3b63a5598f3b2be0ed41e6a558',1,'Argus::IEventProvider::waitForEvents(EventQueue *queue, uint64_t timeout=TIMEOUT_INFINITE)=0']]],
  ['waitforidle',['waitForIdle',['../classArgus_1_1ICaptureSession.html#a75ad81ef8a45909b265ae6a9bb71fc2d',1,'Argus::ICaptureSession']]],
  ['waituntilconnected',['waitUntilConnected',['../classArgus_1_1IStream.html#a2f2a5667b552be1caa483b23d77263ec',1,'Argus::IStream']]]
];
