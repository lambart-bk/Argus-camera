var searchData=
[
  ['rgbcolorchannel',['RGBColorChannel',['../namespaceArgus.html#ad708eaf4e83e4551b95cc2f9a8253674',1,'Argus']]]
];
