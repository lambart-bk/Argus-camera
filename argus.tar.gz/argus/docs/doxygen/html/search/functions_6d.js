var searchData=
[
  ['maxburstrequests',['maxBurstRequests',['../classArgus_1_1ICaptureSession.html#a38362740984f789d726973fa299f144d',1,'Argus::ICaptureSession']]],
  ['move',['move',['../namespaceArgus.html#a76701a19faf999dc35f2a0064c2f52d6',1,'Argus']]]
];
