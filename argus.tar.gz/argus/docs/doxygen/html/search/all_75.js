var searchData=
[
  ['uniqueobj',['UniqueObj',['../classArgus_1_1UniqueObj.html',1,'Argus']]],
  ['uniqueobj',['UniqueObj',['../classArgus_1_1UniqueObj.html#ae4e2ea2238e55327f49e0ec7ad534f35',1,'Argus::UniqueObj::UniqueObj(T *obj=NULL)'],['../classArgus_1_1UniqueObj.html#a2bed2c0a8cc7812275f916e20812c2a4',1,'Argus::UniqueObj::UniqueObj(rv&lt; UniqueObj &gt; &amp;moved)']]],
  ['uuid',['UUID',['../structArgus_1_1UUID.html',1,'Argus']]],
  ['uuid_2eh',['UUID.h',['../UUID_8h.html',1,'']]]
];
