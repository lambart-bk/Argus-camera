var searchData=
[
  ['pixelformat',['PixelFormat',['../classArgus_1_1PixelFormat.html',1,'Argus']]],
  ['pixelformat',['PixelFormat',['../classArgus_1_1PixelFormat.html#a2ccacb56013236a013850b4a8c601a97',1,'Argus::PixelFormat::PixelFormat(uint32_t time_low_, uint16_t time_mid_, uint16_t time_hi_and_version_, uint16_t clock_seq_, uint8_t c0, uint8_t c1, uint8_t c2, uint8_t c3, uint8_t c4, uint8_t c5, const char *name)'],['../classArgus_1_1PixelFormat.html#a26ceb8fb2316522c71bdf3be34df6925',1,'Argus::PixelFormat::PixelFormat()']]]
];
