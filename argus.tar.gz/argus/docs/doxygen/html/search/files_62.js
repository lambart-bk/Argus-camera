var searchData=
[
  ['bayeraveragemap_2eh',['BayerAverageMap.h',['../BayerAverageMap_8h.html',1,'']]],
  ['bayersharpnessmap_2eh',['BayerSharpnessMap.h',['../BayerSharpnessMap_8h.html',1,'']]]
];
