var searchData=
[
  ['location',['Location',['../structArgus_1_1Location.html',1,'Argus']]]
];
