var searchData=
[
  ['bayerchannel',['BayerChannel',['../namespaceArgus.html#a07e5912e70dde696b8bac5c28719a6da',1,'Argus']]]
];
