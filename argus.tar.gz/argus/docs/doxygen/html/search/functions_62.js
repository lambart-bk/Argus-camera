var searchData=
[
  ['b',['b',['../structArgus_1_1BayerTuple.html#a7a405c9d6103ea4b2908dd90024f171c',1,'Argus::BayerTuple::b()'],['../structArgus_1_1BayerTuple.html#a4493be34f517bc456bb2e33bb5a5bc2c',1,'Argus::BayerTuple::b() const ']]],
  ['bayertuple',['BayerTuple',['../structArgus_1_1BayerTuple.html#a9adf5f2f70d07a6103e0c54c5f850dc3',1,'Argus::BayerTuple::BayerTuple()'],['../structArgus_1_1BayerTuple.html#aff79fd7c4401c44ab5c5e187da189da3',1,'Argus::BayerTuple::BayerTuple(T r, T gEven, T gOdd, T b)']]],
  ['begin',['begin',['../classArgus_1_1Array2D.html#a29db9087e0f6db131319b36a60b3766c',1,'Argus::Array2D::begin() const '],['../classArgus_1_1Array2D.html#ab5b7e17b7c4be97161807f931da02e39',1,'Argus::Array2D::begin()']]]
];
