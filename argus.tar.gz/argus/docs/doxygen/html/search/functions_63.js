var searchData=
[
  ['cancelrequests',['cancelRequests',['../classArgus_1_1ICaptureSession.html#a04675ce7ace82c9ffe1f236dc9f55d39',1,'Argus::ICaptureSession']]],
  ['capture',['capture',['../classArgus_1_1ICaptureSession.html#a3e02e8605e5ef5148cdbe79c26cf1fa8',1,'Argus::ICaptureSession']]],
  ['captureburst',['captureBurst',['../classArgus_1_1ICaptureSession.html#af94f311dba11bdd33e1c5f3485cee7e7',1,'Argus::ICaptureSession']]],
  ['checkindex',['checkIndex',['../classArgus_1_1Array2D.html#ad163c996aef3088d76489a29135350ee',1,'Argus::Array2D::checkIndex(uint32_t i) const '],['../classArgus_1_1Array2D.html#abaa546cbd24fd29c32cc172600f9ea03',1,'Argus::Array2D::checkIndex(uint32_t x, uint32_t y) const ']]],
  ['clearoutputstreams',['clearOutputStreams',['../classArgus_1_1IRequest.html#a4fb634e7361d54e0a901cdff5f98dfc7',1,'Argus::IRequest']]],
  ['create',['create',['../classArgus_1_1CameraProvider.html#a900190f5dd0f15ff7fa1dc2a7edb19ac',1,'Argus::CameraProvider']]],
  ['createcapturesession',['createCaptureSession',['../classArgus_1_1ICameraProvider.html#ae84d50114342447dfbc2552a34288608',1,'Argus::ICameraProvider::createCaptureSession(CameraDevice *device, Status *status=NULL)=0'],['../classArgus_1_1ICameraProvider.html#a140866d0ad8bfa19ce850ee1223d52a8',1,'Argus::ICameraProvider::createCaptureSession(const std::vector&lt; CameraDevice * &gt; &amp;devices, Status *status=NULL)=0']]],
  ['createeventqueue',['createEventQueue',['../classArgus_1_1IEventProvider.html#a3bb3a439312b8cba86cbfcb397be63e8',1,'Argus::IEventProvider']]],
  ['createoutputstream',['createOutputStream',['../classArgus_1_1ICaptureSession.html#a5650305125287666054bc3c862a76d84',1,'Argus::ICaptureSession']]],
  ['createoutputstreamsettings',['createOutputStreamSettings',['../classArgus_1_1ICaptureSession.html#a42f57bdf1b73339e2aa26d3a8f1464e1',1,'Argus::ICaptureSession']]],
  ['createrequest',['createRequest',['../classArgus_1_1ICaptureSession.html#afc1d1d0c7ccaae5c96dbddcf98919a10',1,'Argus::ICaptureSession']]]
];
