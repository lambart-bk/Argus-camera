var searchData=
[
  ['status',['Status',['../namespaceArgus.html#a43dee5758547aaf78710c7c1fe122fe3',1,'Argus']]]
];
