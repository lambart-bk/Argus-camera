var searchData=
[
  ['x',['x',['../structArgus_1_1Location.html#a9966874dacaf4735b1a720e878dc16b7',1,'Argus::Location']]]
];
