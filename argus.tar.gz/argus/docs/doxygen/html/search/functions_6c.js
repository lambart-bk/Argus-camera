var searchData=
[
  ['location',['Location',['../structArgus_1_1Location.html#a2aff108a305df24647b799f074a62641',1,'Argus::Location::Location()'],['../structArgus_1_1Location.html#af19e3292ac38e3ca1df80dba2c2073f9',1,'Argus::Location::Location(uint32_t a, uint32_t b)']]]
];
