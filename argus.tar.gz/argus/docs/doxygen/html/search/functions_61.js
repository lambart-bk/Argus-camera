var searchData=
[
  ['acregion',['AcRegion',['../structArgus_1_1AcRegion.html#ac384535f03f0d5f2c792789766de6fb0',1,'Argus::AcRegion::AcRegion()'],['../structArgus_1_1AcRegion.html#ad79f34dcbb992babe1b17b2658acc5f7',1,'Argus::AcRegion::AcRegion(uint32_t _left, uint32_t _top, uint32_t _width, uint32_t _height, float _weight)']]],
  ['array2d',['Array2D',['../classArgus_1_1Array2D.html#a951a8a81048d0a2e221732fed4087729',1,'Argus::Array2D::Array2D()'],['../classArgus_1_1Array2D.html#ab40b4664dfcf6d858a732c60676463d3',1,'Argus::Array2D::Array2D(Size size)'],['../classArgus_1_1Array2D.html#a646ecbf4cbbd800801c865fa0b41e836',1,'Argus::Array2D::Array2D(Size size, const T &amp;value)'],['../classArgus_1_1Array2D.html#afba5aad8e211a848b824b4f4136bfd1b',1,'Argus::Array2D::Array2D(const Array2D&lt; T &gt; &amp;other)']]]
];
