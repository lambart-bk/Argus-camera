var searchData=
[
  ['tuple',['Tuple',['../structArgus_1_1Tuple.html',1,'Argus']]],
  ['tuple_3c_20bayer_5fchannel_5fcount_2c_20t_20_3e',['Tuple&lt; BAYER_CHANNEL_COUNT, T &gt;',['../structArgus_1_1Tuple.html',1,'Argus']]]
];
