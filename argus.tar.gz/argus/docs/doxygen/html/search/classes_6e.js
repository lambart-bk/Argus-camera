var searchData=
[
  ['nameduuid',['NamedUUID',['../classArgus_1_1NamedUUID.html',1,'Argus']]],
  ['noncopyable',['NonCopyable',['../classArgus_1_1NonCopyable.html',1,'Argus']]],
  ['normalizedrect',['NormalizedRect',['../structArgus_1_1NormalizedRect.html',1,'Argus']]]
];
