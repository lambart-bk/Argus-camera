var searchData=
[
  ['weight',['weight',['../structArgus_1_1AcRegion.html#a3f0041f29616d379be5159c33fcea59a',1,'Argus::AcRegion']]],
  ['width',['width',['../structArgus_1_1Rectangle.html#ad3258003afa596c503ff991a7ca8ce45',1,'Argus::Rectangle::width()'],['../structArgus_1_1Size.html#a0f5f889c71cce6db1bad5b3dcc7be4a5',1,'Argus::Size::width()']]]
];
