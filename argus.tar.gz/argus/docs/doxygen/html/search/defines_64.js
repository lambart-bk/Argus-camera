var searchData=
[
  ['define_5fnamed_5fuuid_5fclass',['DEFINE_NAMED_UUID_CLASS',['../UUID_8h.html#a6b1889b812c85beb981b0f8d6db27fbc',1,'UUID.h']]],
  ['define_5fuuid',['DEFINE_UUID',['../UUID_8h.html#a004eb5183e98318035bf466f211c0b10',1,'UUID.h']]]
];
