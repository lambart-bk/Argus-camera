var searchData=
[
  ['rect',['rect',['../structArgus_1_1AcRegion.html#a570551421a44131308aeebcb093c4490',1,'Argus::AcRegion']]],
  ['right',['right',['../structArgus_1_1NormalizedRect.html#ae4ba115d0c031e7f927422ef06585840',1,'Argus::NormalizedRect']]]
];
