var searchData=
[
  ['nameduuid',['NamedUUID',['../classArgus_1_1NamedUUID.html#a3279cd9db732ce6a3c22220dc3c82bfb',1,'Argus::NamedUUID::NamedUUID(uint32_t time_low_, uint16_t time_mid_, uint16_t time_hi_and_version_, uint16_t clock_seq_, uint8_t c0, uint8_t c1, uint8_t c2, uint8_t c3, uint8_t c4, uint8_t c5, const char *name)'],['../classArgus_1_1NamedUUID.html#a8a123a06ef2136fbb946b56935130d66',1,'Argus::NamedUUID::NamedUUID(const NamedUUID &amp;copied)'],['../classArgus_1_1NamedUUID.html#af3b11599e47273125d7b1f5c795b33e5',1,'Argus::NamedUUID::NamedUUID()']]],
  ['noncopyable',['NonCopyable',['../classArgus_1_1NonCopyable.html#a1aad733b06de586e1cee4c0aa8e8ff49',1,'Argus::NonCopyable::NonCopyable()'],['../classArgus_1_1NonCopyable.html#a52f76b8f0c765a71a51a492a9fa59d61',1,'Argus::NonCopyable::NonCopyable(NonCopyable &amp;other)']]],
  ['normalizedrect',['NormalizedRect',['../structArgus_1_1NormalizedRect.html#a1d76cd58bd049b031f0458405391e293',1,'Argus::NormalizedRect::NormalizedRect()'],['../structArgus_1_1NormalizedRect.html#a05eccd6cdd1a00bcbe2cfb09773438b0',1,'Argus::NormalizedRect::NormalizedRect(float l, float t, float r, float b)']]]
];
