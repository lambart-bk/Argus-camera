var searchData=
[
  ['bayertuple',['BayerTuple',['../structArgus_1_1BayerTuple.html',1,'Argus']]]
];
