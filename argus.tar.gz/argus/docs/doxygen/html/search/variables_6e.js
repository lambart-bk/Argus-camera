var searchData=
[
  ['node',['node',['../structArgus_1_1UUID.html#a9634c1f28ccb599d63bd7c92257103ed',1,'Argus::UUID']]],
  ['num_5fawb_5fwb_5festimate_5felements',['NUM_AWB_WB_ESTIMATE_ELEMENTS',['../classArgus_1_1ICaptureMetadata.html#a0ec63067082ae5325083f8f3fe217ba9',1,'Argus::ICaptureMetadata']]],
  ['num_5fcolor_5fcorrection_5felements',['NUM_COLOR_CORRECTION_ELEMENTS',['../classArgus_1_1ICaptureMetadata.html#a66ada0c57da176187dd0bb3ac7e1920f',1,'Argus::ICaptureMetadata']]]
];
