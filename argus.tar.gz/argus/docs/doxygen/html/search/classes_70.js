var searchData=
[
  ['pixelformat',['PixelFormat',['../classArgus_1_1PixelFormat.html',1,'Argus']]]
];
